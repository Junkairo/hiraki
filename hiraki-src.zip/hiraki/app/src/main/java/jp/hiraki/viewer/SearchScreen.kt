package jp.hiraki.viewer

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** 検索画面の状態。本を開いて戻ってきても残るよう、画面の外で持つ */
class SearchState {
    var query by mutableStateOf("")
    var scopeAll by mutableStateOf(true)
    val selected = mutableStateMapOf<String, IndexEntry>()
    var indexVersion by mutableIntStateOf(0)
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun SearchScreen(
    library: Library,
    state: SearchState,
    folderStack: List<Folder>,
    onOpenBook: (Item) -> Unit,
    onClose: () -> Unit,
    onChanged: () -> Unit,
) {
    val folder = folderStack.last()
    val atRoot = folderStack.size <= 1
    var index by remember { mutableStateOf(library.index) }
    var indexing by remember { mutableIntStateOf(-1) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var moveRequest by remember { mutableStateOf<List<MoveTarget>?>(null) }
    val focus = remember { FocusRequester() }

    // 蔵書全体の一覧（索引）を用意する
    LaunchedEffect(state.indexVersion) {
        if (library.index == null) {
            index = null
            indexing = 0
        }
        index = library.ensureIndex { n -> indexing = n }
        indexing = -1
    }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    val selecting = state.selected.isNotEmpty()
    BackHandler(enabled = selecting) { state.selected.clear() }

    val terms = remember(state.query) {
        normalizeForSearch(state.query).split(Regex("\\s+")).filter { it.isNotEmpty() }
    }
    val results = remember(index, terms, state.scopeAll, folder.docId) {
        val all = index ?: return@remember emptyList()
        if (terms.isEmpty()) return@remember emptyList()
        all.filter { e ->
            (state.scopeAll || atRoot || e.chain.contains(folder.docId)) &&
                terms.all { e.normalized.contains(it) }
        }
    }

    Scaffold(
        containerColor = Ground,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Panel),
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "本棚へ戻る")
                    }
                },
                title = {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Slot)
                            .border(1.dp, Accent, RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                    ) {
                        if (state.query.isEmpty()) {
                            Text("ファイル名で検索（スペースで区切ると絞り込み）", color = SubText, fontSize = 15.sp, maxLines = 1)
                        }
                        BasicTextField(
                            value = state.query,
                            onValueChange = { state.query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
                            cursorBrush = SolidColor(Accent),
                            modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        )
                    }
                },
                actions = {
                    if (state.query.isNotEmpty()) {
                        IconButton(onClick = { state.query = "" }) {
                            Icon(Icons.Filled.Clear, contentDescription = "入力を消す")
                        }
                    }
                },
            )
        },
        bottomBar = {
            if (selecting) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Panel)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    IconButton(onClick = { state.selected.clear() }) {
                        Icon(Icons.Filled.Close, contentDescription = "選択をやめる")
                    }
                    Text("${state.selected.size}件を選択中", color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                    TextButton(onClick = { results.forEach { state.selected[it.item.docId] = it } }) {
                        Text("すべて選択")
                    }
                    Button(onClick = {
                        moveRequest = state.selected.values.map { MoveTarget(it.item, it.parentDocId) }
                    }) { Text("移動") }
                }
            }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            // 検索範囲と件数
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ScopeChip("蔵書全体", state.scopeAll || atRoot) { state.scopeAll = true }
                if (!atRoot) {
                    ScopeChip("「${folder.name}」の中", !state.scopeAll) { state.scopeAll = false }
                }
                Box(Modifier.weight(1f))
                if (terms.isNotEmpty() && index != null) {
                    Text("${results.size}件", color = SubText, fontSize = 13.sp)
                }
            }

            if (index == null) {
                Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "蔵書の一覧を作っています… ${maxOf(indexing, 0)}冊",
                        color = SubText,
                    )
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
                    Text("初回だけ時間がかかります。2回目からはすぐ検索できます。", color = SubText, fontSize = 12.sp)
                }
            } else if (terms.isEmpty()) {
                Text(
                    "ファイル名の一部を入力してください。\n全角・半角、カタカナ・ひらがなの違いは気にしなくて大丈夫です。\n長押しで選択して、まとめて移動できます。",
                    color = SubText,
                    modifier = Modifier.padding(24.dp),
                )
            } else if (results.isEmpty()) {
                Text("見つかりませんでした", color = SubText, modifier = Modifier.padding(24.dp))
            } else {
                val listState = rememberLazyListState()
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(bottom = 24.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(results, key = { it.item.docId }) { e ->
                        val isSelected = state.selected.containsKey(e.item.docId)
                        val toggle: () -> Unit = {
                            if (isSelected) {
                                state.selected.remove(e.item.docId)
                            } else {
                                state.selected[e.item.docId] = e
                            }
                            Unit
                        }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(if (isSelected) Accent.copy(alpha = 0.14f) else Color.Transparent)
                                .combinedClickable(
                                    onClick = { if (selecting) toggle() else onOpenBook(e.item) },
                                    onLongClick = { toggle() },
                                )
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            if (selecting) CheckMark(isSelected)
                            CoverImage(
                                e.item,
                                Modifier.width(42.dp).height(60.dp).clip(RoundedCornerShape(2.dp)),
                            )
                            Column(Modifier.weight(1f)) {
                                Text(
                                    highlight(e.item.title, terms),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    e.path + if (e.item.isPdf) "　・PDF" else "",
                                    color = SubText,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    MoveFlow(
        library = library,
        request = moveRequest,
        startStack = folderStack,
        onCancel = { moveRequest = null },
        onFinished = { msg ->
            moveRequest = null
            state.selected.clear()
            state.indexVersion++
            onChanged()
            scope.launch { snackbar.showSnackbar(msg) }
        },
    )
}

@Composable
private fun ScopeChip(label: String, on: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (on) Color.White else SubText,
        fontSize = 13.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (on) Accent else Slot)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
    )
}

@Composable
fun CheckMark(on: Boolean) {
    Box(
        Modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(if (on) Accent else Color(0x66000000))
            .border(1.5.dp, if (on) Accent else Color(0xFFB0B8C4), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (on) Text("✓", color = Color.White, fontSize = 13.sp)
    }
}

/** 一致した部分に色を付ける（正規化で文字数が変わる名前は色付けしない） */
private fun highlight(title: String, terms: List<String>): AnnotatedString {
    val norm = normalizeForSearch(title)
    if (norm.length != title.length) return AnnotatedString(title)
    val marks = BooleanArray(title.length)
    for (t in terms) {
        var from = 0
        while (true) {
            val i = norm.indexOf(t, from)
            if (i < 0) break
            for (k in i until i + t.length) marks[k] = true
            from = i + t.length
        }
    }
    return buildAnnotatedString {
        title.forEachIndexed { i, c ->
            if (marks[i]) {
                pushStyle(SpanStyle(background = Accent.copy(alpha = 0.35f)))
                append(c)
                pop()
            } else {
                append(c)
            }
        }
    }
}
