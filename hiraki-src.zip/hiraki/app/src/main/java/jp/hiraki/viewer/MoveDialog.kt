package jp.hiraki.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 移動したいもの：本（またはフォルダ）と、いま入っているフォルダのID */
class MoveTarget(val item: Item, val parentDocId: String)

/**
 * 移動の流れ（移動先を選ぶ → 移動する → 結果を知らせる）をまとめたもの。
 * requestがnullでない間だけ表示される。
 */
@Composable
fun MoveFlow(
    library: Library,
    request: List<MoveTarget>?,
    startStack: List<Folder>,
    onCancel: () -> Unit,
    onFinished: (message: String) -> Unit,
) {
    if (request == null) return
    val scope = rememberCoroutineScope()
    var moving by remember(request) { mutableStateOf(false) }
    var done by remember(request) { mutableIntStateOf(0) }

    if (!moving) {
        FolderPickerDialog(
            library = library,
            startStack = startStack,
            count = request.size,
            blocked = request.filter { it.item.isDir }.map { it.item.docId }.toSet(),
            onDismiss = onCancel,
            onPick = { dest ->
                moving = true
                scope.launch {
                    var failed = 0
                    var skipped = 0
                    for (t in request) {
                        if (t.parentDocId == dest.docId) {
                            skipped++
                        } else {
                            val ok = withContext(Dispatchers.IO) { library.move(t.item, t.parentDocId, dest.docId) }
                            if (!ok) failed++
                        }
                        done++
                    }
                    library.invalidate()
                    val movedCount = request.size - failed - skipped
                    val msg = buildString {
                        append("${movedCount}件を「${dest.name}」へ移動しました")
                        if (skipped > 0) append("（${skipped}件はすでにそこにあります）")
                        if (failed > 0) append("。${failed}件は移動できませんでした")
                    }
                    onFinished(msg)
                }
            },
        )
    } else {
        Dialog(onDismissRequest = {}) {
            Surface(shape = RoundedCornerShape(14.dp), color = Panel) {
                Column(
                    Modifier.padding(24.dp).widthIn(min = 260.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Text("移動しています… ${done} / ${request.size}", color = MaterialTheme.colorScheme.onSurface)
                    LinearProgressIndicator(
                        progress = { if (request.isEmpty()) 1f else done.toFloat() / request.size },
                        modifier = Modifier.fillMaxWidth(),
                        color = Accent,
                    )
                }
            }
        }
    }
}

/** 移動先のフォルダを選ぶ画面 */
@Composable
fun FolderPickerDialog(
    library: Library,
    startStack: List<Folder>,
    count: Int,
    blocked: Set<String>,
    onDismiss: () -> Unit,
    onPick: (Folder) -> Unit,
) {
    val stack = remember { mutableStateListOf<Folder>().apply { addAll(startStack) } }
    val current = stack.last()
    var reload by remember { mutableIntStateOf(0) }
    var folders by remember(current.docId) { mutableStateOf<List<Item>?>(null) }
    var askName by remember { mutableStateOf(false) }
    var createError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(current.docId, reload) {
        folders = withContext(Dispatchers.IO) {
            runCatching { library.list(current.docId, foldersOnly = true) }.getOrDefault(emptyList())
        }
    }

    // 選んだフォルダ自身やその中には動かせない
    val currentBlocked = blocked.any { library.isInside(current.docId, it) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = Panel,
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.8f),
        ) {
            Column(Modifier.fillMaxSize()) {
                // 見出し
                Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 8.dp)) {
                    Text("${count}件の移動先を選ぶ", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                }
                // いまいる場所
                Row(
                    Modifier.fillMaxWidth().background(Slot).padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { if (stack.size > 1) stack.removeAt(stack.lastIndex) }, enabled = stack.size > 1) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "上のフォルダへ")
                    }
                    Text(
                        stack.joinToString(" / ") { it.name },
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                }
                // サブフォルダの一覧
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    val list = folders
                    when {
                        list == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                        list.isEmpty() -> Text(
                            "サブフォルダはありません",
                            color = SubText,
                            modifier = Modifier.align(Alignment.Center),
                        )
                        else -> LazyColumn(Modifier.fillMaxSize()) {
                            items(list, key = { it.docId }) { f ->
                                val isBlocked = blocked.contains(f.docId)
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable(enabled = !isBlocked) { stack.add(Folder(f.docId, f.name)) }
                                        .padding(horizontal = 20.dp, vertical = 14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Box(Modifier.size(18.dp, 14.dp).background(Color(0xFFFFD27A), RoundedCornerShape(2.dp)))
                                    Spacer(Modifier.size(14.dp))
                                    Text(
                                        f.name + if (isBlocked) "（移動するフォルダ）" else "",
                                        color = if (isBlocked) SubText else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f),
                                    )
                                    if (!isBlocked) {
                                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = SubText)
                                    }
                                }
                                HorizontalDivider(color = Color(0xFF262C37))
                            }
                        }
                    }
                }
                // 操作ボタン
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    TextButton(onClick = { askName = true }, enabled = !currentBlocked) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(4.dp))
                        Text("新しいフォルダ")
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("キャンセル") }
                    Button(onClick = { onPick(current) }, enabled = !currentBlocked) { Text("ここへ移動") }
                }
                createError?.let {
                    Text(it, color = Accent, modifier = Modifier.padding(start = 20.dp, bottom = 12.dp))
                }
            }
        }
    }

    if (askName) {
        NameDialog(
            title = "新しいフォルダ",
            onDismiss = { askName = false },
            onConfirm = { name ->
                askName = false
                scope.launch {
                    val id = withContext(Dispatchers.IO) { library.createFolder(current.docId, name) }
                    if (id == null) {
                        createError = "フォルダを作れませんでした"
                    } else {
                        createError = null
                        library.invalidate()
                        stack.add(Folder(id, name.trim()))
                        reload++
                    }
                }
            },
        )
    }
}

/** 名前を入力してもらう小さなダイアログ */
@Composable
fun NameDialog(title: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val invalid = text.isBlank() || text.any { it in "/\\:*?\"<>|" }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text("フォルダ名") },
                supportingText = {
                    if (text.isNotBlank() && invalid) Text("/ \\ : * ? \" < > | は使えません")
                },
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = !invalid) { Text("作成") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("キャンセル") }
        },
    )
}
