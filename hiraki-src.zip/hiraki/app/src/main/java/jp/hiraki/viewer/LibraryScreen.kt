package jp.hiraki.viewer

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(
    library: Library,
    prefs: BookPrefs,
    stack: List<Folder>,
    gridState: LazyGridState,
    refresh: Int,
    onOpenFolder: (Item) -> Unit,
    onOpenBook: (Item) -> Unit,
    onUp: () -> Unit,
    onSearch: () -> Unit,
    onChangeRoot: () -> Unit,
    onChanged: () -> Unit,
) {
    val folder = stack.last()
    var reload by remember { mutableIntStateOf(0) }
    var items by remember(folder.docId) { mutableStateOf<List<Item>?>(null) }
    var error by remember(folder.docId) { mutableStateOf<String?>(null) }
    LaunchedEffect(folder.docId, refresh, reload) {
        val result = withContext(Dispatchers.IO) { runCatching { library.list(folder.docId) } }
        items = result.getOrNull()
        error = result.exceptionOrNull()?.let { "フォルダを読めませんでした（${it.message}）" }
    }
    var menuOpen by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf(false) }
    val selected = remember(folder.docId) { mutableStateMapOf<String, Item>() }
    val selecting = selected.isNotEmpty()
    var moveRequest by remember { mutableStateOf<List<MoveTarget>?>(null) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    BackHandler(enabled = selecting) { selected.clear() }

    fun toggle(item: Item) {
        if (selected.containsKey(item.docId)) selected.remove(item.docId) else selected[item.docId] = item
    }

    Scaffold(
        containerColor = Ground,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (selecting) {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF3A2224)),
                    navigationIcon = {
                        IconButton(onClick = { selected.clear() }) {
                            Icon(Icons.Filled.Close, contentDescription = "選択をやめる")
                        }
                    },
                    title = { Text("${selected.size}件を選択中") },
                    actions = {
                        TextButton(onClick = { items?.forEach { selected[it.docId] = it } }) { Text("すべて選択") }
                        Button(
                            onClick = { moveRequest = selected.values.map { MoveTarget(it, folder.docId) } },
                            modifier = Modifier.padding(end = 8.dp),
                        ) { Text("移動") }
                    },
                )
            } else {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Panel),
                    title = {
                        Column {
                            Text(folder.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (stack.size > 1) {
                                Text(
                                    stack.dropLast(1).joinToString(" / ") { it.name },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SubText,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        if (stack.size > 1) {
                            IconButton(onClick = onUp) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "上のフォルダへ")
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = onSearch) {
                            Icon(Icons.Filled.Search, contentDescription = "検索")
                        }
                        IconButton(onClick = { library.invalidate(); reload++ }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "再読み込み")
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Filled.MoreVert, contentDescription = "メニュー")
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("ここに新しいフォルダ") },
                                    onClick = { menuOpen = false; newFolder = true },
                                )
                                DropdownMenuItem(
                                    text = { Text("蔵書フォルダを変更") },
                                    onClick = { menuOpen = false; onChangeRoot() },
                                )
                                DropdownMenuItem(
                                    text = { Text("バージョン $APP_VERSION", color = SubText) },
                                    onClick = { menuOpen = false },
                                )
                            }
                        }
                    },
                )
            }
        },
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            val list = items
            when {
                error != null -> Text(error ?: "", color = SubText, modifier = Modifier.align(Alignment.Center).padding(24.dp))
                list == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                list.isEmpty() -> Text(
                    "このフォルダには本（cbz・zip・pdf）がありません",
                    color = SubText,
                    modifier = Modifier.align(Alignment.Center),
                )
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 128.dp),
                    state = gridState,
                    contentPadding = PaddingValues(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(list, key = { it.docId }) { item ->
                        val isSelected = selected.containsKey(item.docId)
                        val tileModifier = Modifier.combinedClickable(
                            onClick = {
                                when {
                                    selecting -> toggle(item)
                                    item.isDir -> onOpenFolder(item)
                                    else -> onOpenBook(item)
                                }
                            },
                            onLongClick = { toggle(item) },
                        )
                        Box {
                            if (item.isDir) {
                                FolderTile(library, item, tileModifier)
                            } else {
                                BookTile(item, prefs.progress(item.bookKey), tileModifier)
                            }
                            if (selecting) {
                                Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) { CheckMark(isSelected) }
                            }
                            if (isSelected) {
                                Box(
                                    Modifier
                                        .matchParentSize()
                                        .border(2.dp, Accent, RoundedCornerShape(6.dp))
                                        .background(Accent.copy(alpha = 0.12f), RoundedCornerShape(6.dp)),
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    MoveFlow(
        library = library,
        request = moveRequest,
        startStack = stack,
        onCancel = { moveRequest = null },
        onFinished = { msg ->
            moveRequest = null
            selected.clear()
            reload++
            onChanged()
            scope.launch { snackbar.showSnackbar(msg) }
        },
    )

    if (newFolder) {
        NameDialog(
            title = "「${folder.name}」に新しいフォルダ",
            onDismiss = { newFolder = false },
            onConfirm = { name ->
                newFolder = false
                scope.launch {
                    val id = withContext(Dispatchers.IO) { library.createFolder(folder.docId, name) }
                    library.invalidate()
                    reload++
                    snackbar.showSnackbar(if (id != null) "フォルダ「${name.trim()}」を作りました" else "フォルダを作れませんでした")
                }
            },
        )
    }
}

@Composable
fun CoverImage(item: Item, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val state = remember(item.docId, item.lastModified) { mutableStateOf(Thumbnails.cached(item)) }
    LaunchedEffect(item.docId, item.lastModified) {
        if (state.value == null) state.value = Thumbnails.load(context, item)
    }
    val bitmap: Bitmap? = state.value
    Box(modifier.background(Color(0xFF2A313C))) {
        bitmap?.let { bmp ->
            val image = remember(bmp) { bmp.asImageBitmap() }
            Image(image, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
fun BookTile(item: Item, progress: Float, modifier: Modifier) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Box {
            CoverImage(
                item,
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.7f)
                    .clip(RoundedCornerShape(3.dp)),
            )
            if (item.isPdf) {
                Text(
                    "PDF",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(4.dp)
                        .background(Color(0xD9C8372D), RoundedCornerShape(3.dp))
                        .padding(horizontal = 5.dp, vertical = 1.dp),
                )
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(Color(0xFF2A313C)),
        ) {
            if (progress > 0f) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(progress).background(Accent))
            }
        }
        Text(
            item.title,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun FolderTile(library: Library, item: Item, modifier: Modifier) {
    val previewState = remember(item.docId) { mutableStateOf(library.cachedPreview(item.docId)) }
    LaunchedEffect(item.docId) {
        if (previewState.value == null) {
            previewState.value = withContext(Dispatchers.IO) { runCatching { library.folderPreview(item.docId) }.getOrNull() }
        }
    }
    val preview = previewState.value
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.7f)
                .clip(RoundedCornerShape(6.dp))
                .background(Slot)
                .padding(4.dp),
        ) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                for (row in 0..1) {
                    Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        for (col in 0..1) {
                            val cover = preview?.covers?.getOrNull(row * 2 + col)
                            val cell = Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(2.dp))
                            if (cover != null) {
                                CoverImage(cover, cell)
                            } else {
                                Box(cell.border(1.dp, Color(0xFF3A4250), RoundedCornerShape(2.dp)))
                            }
                        }
                    }
                }
            }
            preview?.let {
                Text(
                    "${it.count}",
                    color = Color.White,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .background(Color(0xD90A0C10), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 1.dp),
                )
            }
        }
        Text(
            item.name,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
