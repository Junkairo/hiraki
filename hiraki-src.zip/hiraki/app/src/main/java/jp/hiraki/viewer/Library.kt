package jp.hiraki.viewer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.text.Normalizer
import java.util.concurrent.ConcurrentHashMap

data class Item(
    val docId: String,
    val uri: Uri,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val lastModified: Long,
) {
    val bookKey: String get() = "$name|$size"
    val title: String
        get() = if (isDir) name else name.replace(Regex("\\.(cbz|zip|pdf)$", RegexOption.IGNORE_CASE), "")
    val isPdf: Boolean get() = bookTypeOf(name) == BookType.PDF
}

/** 検索用の1件。chainは蔵書フォルダからの親フォルダIDの並び、pathは表示用のフォルダ名の並び */
class IndexEntry(
    val item: Item,
    val parentDocId: String,
    val chain: List<String>,
    val path: String,
) {
    val normalized: String = normalizeForSearch(item.title)
}

/** 全角/半角、大文字/小文字、カタカナ/ひらがなの違いを無視して比べるための変換 */
fun normalizeForSearch(s: String): String {
    val nfkc = Normalizer.normalize(s, Normalizer.Form.NFKC).lowercase()
    val sb = StringBuilder(nfkc.length)
    for (c in nfkc) {
        sb.append(if (c in 'ァ'..'ヶ') c - 0x60 else c)
    }
    return sb.toString()
}

/** 蔵書フォルダ（SAFで許可をもらったフォルダ）の中身を読む・動かす */
class Library(private val context: Context, val treeUri: Uri) {

    val rootDocId: String = DocumentsContract.getTreeDocumentId(treeUri)

    fun docUri(docId: String): Uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)

    /** フォルダ内のサブフォルダと本（cbz/zip/pdf）を、フォルダ→本の順・自然順で返す */
    fun list(docId: String, foldersOnly: Boolean = false): List<Item> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
        val cols = arrayOf(
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE,
            Document.COLUMN_LAST_MODIFIED,
        )
        val out = ArrayList<Item>()
        context.contentResolver.query(childrenUri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                if (name.startsWith(".")) continue
                val isDir = c.getString(2) == Document.MIME_TYPE_DIR
                if (!isDir && (foldersOnly || bookTypeOf(name) == null)) continue
                out.add(
                    Item(
                        docId = id,
                        uri = docUri(id),
                        name = name,
                        isDir = isDir,
                        size = if (c.isNull(3)) 0L else c.getLong(3),
                        lastModified = if (c.isNull(4)) 0L else c.getLong(4),
                    )
                )
            }
        }
        return out.sortedWith(
            compareBy<Item> { !it.isDir }.thenComparator { a, b -> NaturalOrder.compare(a.name, b.name) }
        )
    }

    // ---------- フォルダの書影 ----------

    class FolderPreview(val covers: List<Item>, val count: Int)

    private val previewCache = ConcurrentHashMap<String, FolderPreview>()

    fun cachedPreview(docId: String): FolderPreview? = previewCache[docId]

    /** フォルダのタイル用：中の本を4冊まで。足りなければサブフォルダの中から拾う */
    fun folderPreview(docId: String): FolderPreview =
        previewCache[docId] ?: buildPreview(docId).also { previewCache[docId] = it }

    private fun buildPreview(docId: String): FolderPreview {
        val children = list(docId)
        val covers = ArrayList<Item>()
        covers.addAll(children.filter { !it.isDir }.take(4))
        if (covers.size < 4) {
            for (dir in children.filter { it.isDir }) {
                if (covers.size >= 4) break
                covers.addAll(list(dir.docId).filter { !it.isDir }.take(4 - covers.size))
            }
        }
        return FolderPreview(covers, children.size)
    }

    // ---------- 検索用の索引 ----------

    @Volatile
    var index: List<IndexEntry>? = null
        private set
    private val indexLock = Mutex()

    /** 蔵書フォルダ全体をたどって、本の一覧を作る（一度作ったら覚えておく） */
    suspend fun ensureIndex(onProgress: (Int) -> Unit): List<IndexEntry> = indexLock.withLock {
        index?.let { return@withLock it }
        withContext(Dispatchers.IO) {
            val out = ArrayList<IndexEntry>()
            data class Pending(val docId: String, val chain: List<String>, val path: String)
            val queue = ArrayDeque<Pending>()
            queue.add(Pending(rootDocId, listOf(rootDocId), "蔵書"))
            while (queue.isNotEmpty()) {
                ensureActive()
                val dir = queue.removeFirst()
                val children = runCatching { list(dir.docId) }.getOrDefault(emptyList())
                for (child in children) {
                    if (child.isDir) {
                        queue.add(Pending(child.docId, dir.chain + child.docId, dir.path + " / " + child.name))
                    } else {
                        out.add(IndexEntry(child, dir.docId, dir.chain, dir.path))
                    }
                }
                onProgress(out.size)
            }
            out.sortWith { a, b -> NaturalOrder.compare(a.item.name, b.item.name) }
            index = out
            out
        }
    }

    // ---------- 変更したときの後始末 ----------

    fun invalidate() {
        previewCache.clear()
        index = null
    }

    // ---------- 移動・フォルダ作成 ----------

    /** 新しいフォルダを作る。成功したらそのIDを返す */
    fun createFolder(parentDocId: String, name: String): String? = runCatching {
        val uri = DocumentsContract.createDocument(
            context.contentResolver, docUri(parentDocId), Document.MIME_TYPE_DIR, name.trim(),
        ) ?: return null
        DocumentsContract.getDocumentId(uri)
    }.getOrNull()

    /** 移動先として選べないフォルダか（自分自身や自分の中へは動かせない） */
    fun isInside(targetDocId: String, folderDocId: String): Boolean =
        targetDocId == folderDocId || targetDocId.startsWith("$folderDocId/")

    /**
     * ファイル（またはフォルダ）を移動する。
     * まず端末の「移動」機能を使い、使えない場合はファイルだけ「コピーして元を削除」で代わりに行う。
     */
    fun move(item: Item, fromParentDocId: String, toParentDocId: String): Boolean {
        if (fromParentDocId == toParentDocId) return true
        if (item.isDir && isInside(toParentDocId, item.docId)) return false
        val resolver = context.contentResolver
        try {
            val moved = DocumentsContract.moveDocument(resolver, item.uri, docUri(fromParentDocId), docUri(toParentDocId))
            if (moved != null) return true
        } catch (_: Exception) {
            // 下のコピー方式へ
        }
        if (item.isDir) return false
        return try {
            val newUri = DocumentsContract.createDocument(
                resolver, docUri(toParentDocId), "application/octet-stream", item.name,
            ) ?: return false
            val input = resolver.openInputStream(item.uri) ?: return false
            val output = resolver.openOutputStream(newUri) ?: run { input.close(); return false }
            input.use { i -> output.use { o -> i.copyTo(o, 1 shl 16) } }
            DocumentsContract.deleteDocument(resolver, item.uri)
        } catch (_: Exception) {
            false
        }
    }
}

/** 書影（表紙のサムネイル）。一度作ったら端末内に保存しておく */
object Thumbnails {
    private const val THUMB_W = 240

    private val memory = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }
    private val gate = Semaphore(4)

    private fun key(item: Item): String {
        val md = MessageDigest.getInstance("SHA-1")
        val bytes = md.digest("${item.name}|${item.size}|${item.lastModified}".toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun cached(item: Item): Bitmap? = memory.get(key(item))

    suspend fun load(context: Context, item: Item): Bitmap? {
        val k = key(item)
        memory.get(k)?.let { return it }
        return gate.withPermit {
            withContext(Dispatchers.IO) {
                memory.get(k) ?: run {
                    val file = File(context.cacheDir, "thumbs/$k.jpg")
                    val bmp = if (file.exists()) {
                        BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply {
                            inPreferredConfig = Bitmap.Config.RGB_565
                        })
                    } else {
                        generate(context, item, file)
                    }
                    bmp?.also { memory.put(k, it) }
                }
            }
        }
    }

    private fun generate(context: Context, item: Item, file: File): Bitmap? = runCatching {
        openBook(context, item).use { book ->
            if (book.pageCount == 0) return@use null
            var src = book.decode(0, THUMB_W, THUMB_W * 2, hardware = false) ?: return@use null
            // 表紙が見開きで1枚になっている場合は、右半分（右綴じの表紙側）を使う
            if (src.width > src.height * 1.1f) {
                val half = Bitmap.createBitmap(src, src.width / 2, 0, src.width / 2, src.height)
                if (half !== src) src.recycle()
                src = half
            }
            val h = (src.height.toLong() * THUMB_W / src.width).toInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(src, THUMB_W, h, true)
            if (scaled !== src) src.recycle()
            file.parentFile?.mkdirs()
            file.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            scaled
        }
    }.getOrNull()
}
