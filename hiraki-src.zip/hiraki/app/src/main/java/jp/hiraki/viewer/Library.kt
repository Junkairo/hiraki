package jp.hiraki.viewer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

data class Item(
    val docId: String,
    val uri: Uri,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val lastModified: Long,
) {
    val bookKey: String get() = "$name|$size"
    val title: String get() = if (isDir) name else name.removeSuffix(".cbz").removeSuffix(".CBZ")
}

/** 蔵書フォルダ（SAFで許可をもらったフォルダ）の中身を読む */
class Library(private val context: Context, val treeUri: Uri) {

    val rootDocId: String = DocumentsContract.getTreeDocumentId(treeUri)

    private fun docUri(docId: String): Uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)

    /** フォルダ内のサブフォルダとcbzを、フォルダ→本の順・自然順で返す */
    fun list(docId: String): List<Item> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
        val cols = arrayOf(
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE,
            Document.COLUMN_LAST_MODIFIED,
        )
        val out = ArrayList<Item>()
        context.contentResolver.query(childrenUri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                if (name.startsWith(".")) continue
                val isDir = c.getString(2) == Document.MIME_TYPE_DIR
                if (!isDir && !name.lowercase().endsWith(".cbz")) continue
                out.add(
                    Item(
                        docId = id,
                        uri = docUri(id),
                        name = name,
                        isDir = isDir,
                        size = if (c.isNull(3)) 0L else c.getLong(3),
                        lastModified = if (c.isNull(4)) 0L else c.getLong(4),
                    )
                )
            }
        }
        return out.sortedWith(
            compareBy<Item> { !it.isDir }.thenComparator { a, b -> NaturalOrder.compare(a.name, b.name) }
        )
    }

    class FolderPreview(val covers: List<Item>, val count: Int)

    private val previewCache = java.util.concurrent.ConcurrentHashMap<String, FolderPreview>()

    fun cachedPreview(docId: String): FolderPreview? = previewCache[docId]
    fun clearPreviewCache() = previewCache.clear()

    /** フォルダのタイル用：中の本を4冊まで。足りなければサブフォルダの中から拾う */
    fun folderPreview(docId: String): FolderPreview =
        previewCache[docId] ?: buildPreview(docId).also { previewCache[docId] = it }

    private fun buildPreview(docId: String): FolderPreview {
        val children = list(docId)
        val covers = ArrayList<Item>()
        covers.addAll(children.filter { !it.isDir }.take(4))
        if (covers.size < 4) {
            for (dir in children.filter { it.isDir }) {
                if (covers.size >= 4) break
                covers.addAll(list(dir.docId).filter { !it.isDir }.take(4 - covers.size))
            }
        }
        return FolderPreview(covers, children.size)
    }
}

/** 書影（表紙のサムネイル）。一度作ったら端末内に保存しておく */
object Thumbnails {
    private const val THUMB_W = 240

    private val memory = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }
    private val gate = Semaphore(4)

    private fun key(item: Item): String {
        val md = MessageDigest.getInstance("SHA-1")
        val bytes = md.digest("${item.docId}|${item.size}|${item.lastModified}".toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun cached(item: Item): Bitmap? = memory.get(key(item))

    suspend fun load(context: Context, item: Item): Bitmap? {
        val k = key(item)
        memory.get(k)?.let { return it }
        return gate.withPermit {
            withContext(Dispatchers.IO) {
                memory.get(k) ?: run {
                    val file = File(context.cacheDir, "thumbs/$k.jpg")
                    val bmp = if (file.exists()) {
                        BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply {
                            inPreferredConfig = Bitmap.Config.RGB_565
                        })
                    } else {
                        generate(context, item, file)
                    }
                    bmp?.also { memory.put(k, it) }
                }
            }
        }
    }

    private fun generate(context: Context, item: Item, file: File): Bitmap? = runCatching {
        CbzArchive.open(context, item.uri).use { archive ->
            val first = archive.pages.firstOrNull() ?: return@use null
            var src = decodeSampled(archive.readBytes(first), THUMB_W, THUMB_W) ?: return@use null
            // 表紙が見開きで1枚になっている場合は、右半分（右綴じの表紙側）を使う
            if (src.width > src.height * 1.1f) {
                val half = Bitmap.createBitmap(src, src.width / 2, 0, src.width / 2, src.height)
                if (half !== src) src.recycle()
                src = half
            }
            val h = (src.height.toLong() * THUMB_W / src.width).toInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(src, THUMB_W, h, true)
            if (scaled !== src) src.recycle()
            file.parentFile?.mkdirs()
            file.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            scaled
        }
    }.getOrNull()
}
