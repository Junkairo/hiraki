package jp.hiraki.viewer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory

const val APP_VERSION = "0.3"

/** 「No2」が「No10」より前に来る並べ方（全角数字にも対応） */
object NaturalOrder : Comparator<String> {
    private fun isDigit(c: Char) = Character.digit(c, 10) >= 0

    override fun compare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (isDigit(ca) && isDigit(cb)) {
                var si = i; while (si < a.length && Character.digit(a[si], 10) == 0) si++
                var sj = j; while (sj < b.length && Character.digit(b[sj], 10) == 0) sj++
                var ei = si; while (ei < a.length && isDigit(a[ei])) ei++
                var ej = sj; while (ej < b.length && isDigit(b[ej])) ej++
                val la = ei - si
                val lb = ej - sj
                if (la != lb) return la - lb
                for (k in 0 until la) {
                    val d = Character.digit(a[si + k], 10) - Character.digit(b[sj + k], 10)
                    if (d != 0) return d
                }
                // 数字部分の終わりまで進める（先頭の0も含めて）
                while (i < a.length && isDigit(a[i])) i++
                while (j < b.length && isDigit(b[j])) j++
            } else {
                val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
                if (c != 0) return c
                i++
                j++
            }
        }
        return (a.length - i) - (b.length - j)
    }
}

/** 必要な大きさ以上を保ちつつ、なるべく小さくデコードする */
fun decodeSampled(bytes: ByteArray, reqW: Int, reqH: Int, config: Bitmap.Config = Bitmap.Config.ARGB_8888): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= reqW && bounds.outHeight / (sample * 2) >= reqH) sample *= 2
    val opts = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = config
    }
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
}

/**
 * 見開きの組み方。
 * shifted=false：表紙(1)だけ単独 → 2–3, 4–5 …
 * shifted=true ：1–2, 3–4 …
 * 中身はページ番号（0始まり）の配列。
 */
fun buildSpreads(count: Int, shifted: Boolean, spread: Boolean): List<IntArray> {
    if (count <= 0) return emptyList()
    if (!spread) return List(count) { intArrayOf(it) }
    val out = ArrayList<IntArray>()
    var i = 0
    if (!shifted) {
        out.add(intArrayOf(0))
        i = 1
    }
    while (i < count) {
        out.add(if (i + 1 < count) intArrayOf(i, i + 1) else intArrayOf(i))
        i += 2
    }
    return out
}

fun spreadIndexOf(spreads: List<IntArray>, page: Int): Int =
    spreads.indexOfFirst { page in it }.coerceAtLeast(0)

/** 本ごとの設定と読んだ位置。キーは「ファイル名|サイズ」なので、移動しても引き継がれる */
class BookPrefs(context: Context) {
    private val sp = context.getSharedPreferences("books", Context.MODE_PRIVATE)

    fun page(key: String) = sp.getInt("p:$key", 0)
    fun shifted(key: String) = sp.getBoolean("s:$key", false)
    fun rtl(key: String) = sp.getBoolean("r:$key", true)

    /** 0=自動（横持ちで見開き） 1=単ページ 2=見開き */
    fun mode(key: String) = sp.getInt("m:$key", 0)

    fun progress(key: String): Float {
        val n = sp.getInt("n:$key", 0)
        if (n <= 1) return 0f
        val p = sp.getInt("p:$key", 0)
        return if (p == 0) 0f else ((p + 1).toFloat() / n).coerceIn(0f, 1f)
    }

    /** めくり効果（全体設定） */
    fun flipEffect() = sp.getBoolean("g:flip", true)
    fun setFlipEffect(on: Boolean) = sp.edit().putBoolean("g:flip", on).apply()

    fun save(key: String, page: Int, count: Int, shifted: Boolean, rtl: Boolean, mode: Int) {
        sp.edit()
            .putInt("p:$key", page)
            .putInt("n:$key", count)
            .putBoolean("s:$key", shifted)
            .putBoolean("r:$key", rtl)
            .putInt("m:$key", mode)
            .apply()
    }
}
