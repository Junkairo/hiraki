package jp.hiraki.viewer

import android.app.Activity
import android.content.res.Configuration
import android.graphics.Bitmap
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

/** デコード済みページの一時置き場（前後のページを先読みしておく） */
class PageCache(private val archive: CbzArchive) {
    private val cache = object : LruCache<Int, Bitmap>(96 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap) = value.byteCount / 1024
    }

    fun peek(index: Int): Bitmap? = cache.get(index)

    suspend fun load(index: Int, reqW: Int, reqH: Int): Bitmap? = withContext(Dispatchers.IO) {
        cache.get(index) ?: runCatching {
            decodeSampled(archive.readBytes(archive.pages[index]), reqW, reqH)
        }.getOrNull()?.also { cache.put(index, it) }
    }
}

@Composable
fun ViewerScreen(item: Item, prefs: BookPrefs, onClose: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    var archive by remember { mutableStateOf<CbzArchive?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(item.uri) {
        try {
            archive = withContext(Dispatchers.IO) { CbzArchive.open(context, item.uri) }
        } catch (e: Exception) {
            error = "開けませんでした（${e.message}）"
        }
    }
    DisposableEffect(item.uri) {
        onDispose { archive?.close() }
    }

    // 全画面表示・画面を消さない
    DisposableEffect(Unit) {
        val window = (view.context as Activity).window
        val controller = WindowCompat.getInsetsController(window, view)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        view.keepScreenOn = true
        onDispose {
            controller.show(WindowInsetsCompat.Type.systemBars())
            view.keepScreenOn = false
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF050608))) {
        val a = archive
        when {
            error != null -> Text(error ?: "", color = SubText, modifier = Modifier.align(Alignment.Center).padding(24.dp))
            a == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
            a.pages.isEmpty() -> Text("画像が見つかりませんでした", color = SubText, modifier = Modifier.align(Alignment.Center))
            else -> BookView(item, a, prefs, onClose)
        }
    }
}

@Composable
private fun BookView(item: Item, archive: CbzArchive, prefs: BookPrefs, onClose: () -> Unit) {
    val key = item.bookKey
    val count = archive.pages.size
    val cache = remember(archive) { PageCache(archive) }

    var shifted by remember { mutableStateOf(prefs.shifted(key)) }
    var rtl by remember { mutableStateOf(prefs.rtl(key)) }
    var mode by remember { mutableStateOf(prefs.mode(key)) }
    var page by remember { mutableStateOf(prefs.page(key).coerceIn(0, count - 1)) }
    var showBar by remember { mutableStateOf(false) }

    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val spreadOn = when (mode) {
        1 -> false
        2 -> true
        else -> landscape
    }
    val spreads = remember(count, shifted, spreadOn) { buildSpreads(count, shifted, spreadOn) }
    val index = spreadIndexOf(spreads, page)
    val current = spreads[index]

    LaunchedEffect(page, shifted, rtl, mode) {
        prefs.save(key, page, count, shifted, rtl, mode)
    }

    fun go(delta: Int) {
        val n = (index + delta).coerceIn(0, spreads.lastIndex)
        page = spreads[n][0]
    }
    val goNext by rememberUpdatedState({ go(1) })
    val goPrev by rememberUpdatedState({ go(-1) })
    val isRtl by rememberUpdatedState(rtl)

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val screenW = with(density) { maxWidth.roundToPx() }
        val screenH = with(density) { maxHeight.roundToPx() }
        val pageW = if (current.size == 2) screenW / 2 else screenW

        // 次の見開きを先読み
        LaunchedEffect(index, spreads, screenW, screenH) {
            spreads.getOrNull(index + 1)?.forEach { cache.load(it, pageW, screenH) }
            spreads.getOrNull(index - 1)?.forEach { cache.load(it, pageW, screenH) }
        }

        Row(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { pos ->
                        val third = size.width / 3f
                        when {
                            pos.x < third -> if (isRtl) goNext() else goPrev()
                            pos.x > size.width - third -> if (isRtl) goPrev() else goNext()
                            else -> showBar = !showBar
                        }
                    }
                }
                .pointerInput(Unit) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = {
                            if (abs(total) > 80.dp.toPx()) {
                                // 右綴じ：左から右へスワイプで次へ
                                val forward = if (isRtl) total > 0 else total < 0
                                if (forward) goNext() else goPrev()
                            }
                        },
                        onHorizontalDrag = { change, dx ->
                            change.consume()
                            total += dx
                        },
                    )
                },
        ) {
            // 右綴じなら若い番号のページを右に置く
            val ordered = if (rtl) current.reversed() else current.toList()
            if (ordered.size == 1) {
                PageImage(cache, ordered[0], pageW, screenH, Alignment.Center, Modifier.fillMaxSize())
            } else {
                PageImage(cache, ordered[0], pageW, screenH, Alignment.CenterEnd, Modifier.weight(1f).fillMaxHeight())
                PageImage(cache, ordered[1], pageW, screenH, Alignment.CenterStart, Modifier.weight(1f).fillMaxHeight())
            }
        }

        if (showBar) {
            ViewerBars(
                title = item.title,
                current = current,
                count = count,
                spreads = spreads,
                index = index,
                rtl = rtl,
                mode = mode,
                shifted = shifted,
                spreadOn = spreadOn,
                onClose = onClose,
                onMode = { mode = it },
                onRtl = { rtl = it },
                onShift = { shifted = !shifted },
                onSeek = { page = spreads[it][0] },
            )
        }
    }
}

@Composable
private fun PageImage(cache: PageCache, index: Int, reqW: Int, reqH: Int, alignment: Alignment, modifier: Modifier) {
    val bitmap by produceState(cache.peek(index), index, reqW, reqH) {
        if (value == null) value = cache.load(index, reqW, reqH)
    }
    Box(modifier) {
        val bmp = bitmap
        if (bmp != null) {
            val image = remember(bmp) { bmp.asImageBitmap() }
            Image(
                image,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                alignment = alignment,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = SubText)
        }
    }
}

@Composable
private fun ViewerBars(
    title: String,
    current: IntArray,
    count: Int,
    spreads: List<IntArray>,
    index: Int,
    rtl: Boolean,
    mode: Int,
    shifted: Boolean,
    spreadOn: Boolean,
    onClose: () -> Unit,
    onMode: (Int) -> Unit,
    onRtl: (Boolean) -> Unit,
    onShift: () -> Unit,
    onSeek: (Int) -> Unit,
) {
    val barColor = Color(0xEB1B2029)
    Box(Modifier.fillMaxSize()) {
        // 上のバー
        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .pointerInput(Unit) { detectTapGestures { } }
                .background(barColor)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "本棚へ戻る", tint = Color.White)
            }
            Text(
                title,
                color = SubText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Segmented(listOf("自動", "単", "見開"), mode, onMode)
            Segmented(listOf("右綴じ", "左綴じ"), if (rtl) 0 else 1) { onRtl(it == 0) }
        }

        // 下のバー
        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .pointerInput(Unit) { detectTapGestures { } }
                .background(barColor)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            val shiftColor = when {
                !spreadOn -> Color(0xFF3A4250)
                shifted -> Accent
                else -> Color(0xFF2E3542)
            }
            Text(
                if (shifted) "⇆ ずらし中" else "⇆ 1ページずらす",
                color = if (spreadOn) Color.White else SubText,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(shiftColor)
                    .clickable(enabled = spreadOn, onClick = onShift)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            )
            Box(Modifier.weight(1f)) {
                if (spreads.size > 1) {
                    // 右綴じのときはスライダーも右から左へ
                    CompositionLocalProvider(
                        LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
                    ) {
                        Slider(
                            value = index.toFloat(),
                            onValueChange = { onSeek(it.roundToInt().coerceIn(0, spreads.lastIndex)) },
                            valueRange = 0f..spreads.lastIndex.toFloat(),
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Accent),
                        )
                    }
                }
            }
            val label = if (current.size == 2) "${current[0] + 1}–${current[1] + 1}" else "${current[0] + 1}"
            Text("$label / $count", color = SubText, fontSize = 13.sp)
        }
    }
}

@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF3A4250), RoundedCornerShape(8.dp)),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Text(
                label,
                color = if (on) Color(0xFF111111) else SubText,
                fontSize = 13.sp,
                modifier = Modifier
                    .background(if (on) Color(0xFFE9ECF1) else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}
