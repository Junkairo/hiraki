package jp.hiraki.viewer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Accent = Color(0xFFE8574C)
val Ground = Color(0xFF101318)
val Panel = Color(0xFF1B2029)
val Slot = Color(0xFF232A35)
val SubText = Color(0xFF8C95A3)

class MainActivity : ComponentActivity() {

    private var treeUri by mutableStateOf<Uri?>(null)

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
            getSharedPreferences("app", MODE_PRIVATE).edit().putString("tree", uri.toString()).apply()
            treeUri = uri
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        treeUri = getSharedPreferences("app", MODE_PRIVATE).getString("tree", null)
            ?.let { Uri.parse(it) }
            ?.takeIf { saved -> contentResolver.persistedUriPermissions.any { it.uri == saved && it.isReadPermission } }

        val bookPrefs = BookPrefs(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent,
                    background = Ground,
                    surface = Panel,
                    onSurface = Color(0xFFE9ECF1),
                    onBackground = Color(0xFFE9ECF1),
                    surfaceVariant = Slot,
                )
            ) {
                val uri = treeUri
                if (uri == null) {
                    Welcome(onPick = { picker.launch(null) })
                } else {
                    val library = remember(uri) { Library(applicationContext, uri) }
                    App(library, bookPrefs, onChangeRoot = { picker.launch(null) })
                }
            }
        }
    }
}

data class Folder(val docId: String, val name: String)

@Composable
fun App(library: Library, prefs: BookPrefs, onChangeRoot: () -> Unit) {
    val stack = remember(library) { mutableStateListOf(Folder(library.rootDocId, "蔵書")) }
    val gridStates = remember(library) { mutableMapOf<String, LazyGridState>() }
    var reading by remember { mutableStateOf<Item?>(null) }
    var refresh by remember { mutableIntStateOf(0) }

    val book = reading
    if (book != null) {
        val close: () -> Unit = {
            reading = null
            refresh++
        }
        BackHandler(onBack = close)
        ViewerScreen(book, prefs, onClose = close)
    } else {
        BackHandler(enabled = stack.size > 1) { stack.removeAt(stack.lastIndex) }
        val folder = stack.last()
        LibraryScreen(
            library = library,
            prefs = prefs,
            stack = stack,
            gridState = gridStates.getOrPut(folder.docId) { LazyGridState() },
            refresh = refresh,
            onOpenFolder = { stack.add(Folder(it.docId, it.name)) },
            onOpenBook = { reading = it },
            onUp = { if (stack.size > 1) stack.removeAt(stack.lastIndex) },
            onChangeRoot = onChangeRoot,
        )
    }
}

@Composable
fun Welcome(onPick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ground)
            .padding(32.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("ヒラキ", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onBackground)
        Text(
            "cbzファイルを入れている蔵書フォルダを選んでください。\n一度選べば、次からはすぐ本棚が開きます。",
            color = SubText,
            modifier = Modifier.widthIn(max = 420.dp),
        )
        Button(onClick = onPick) { Text("蔵書フォルダを選ぶ") }
    }
}
