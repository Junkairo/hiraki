package jp.hiraki.viewer

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.Closeable
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.nio.charset.Charset
import java.util.zip.Inflater

/**
 * cbz（ZIP）を開いて、中の画像を1枚ずつ取り出すクラス。
 * ZIP末尾の目次（セントラルディレクトリ）だけを読むので、大きなファイルでもすぐ開ける。
 */
class CbzArchive private constructor(
    private val pfd: ParcelFileDescriptor,
    private val stream: FileInputStream,
    private val channel: FileChannel,
) : Closeable {

    class Entry(
        val name: String,
        val method: Int,
        val compressedSize: Long,
        val size: Long,
        val localHeaderOffset: Long,
    )

    /** 画像ファイルだけを、ファイル名の自然順に並べたもの */
    var pages: List<Entry> = emptyList()
        private set

    companion object {
        private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

        // 日本語ファイル名（Windowsで作ったZIPはShift_JIS系が多い）
        private val legacyCharset: Charset = listOf("windows-31j", "MS932", "Shift_JIS")
            .firstNotNullOfOrNull { runCatching { Charset.forName(it) }.getOrNull() }
            ?: Charsets.ISO_8859_1

        fun open(context: Context, uri: Uri): CbzArchive {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                ?: throw IOException("ファイルを開けません")
            val fis = FileInputStream(pfd.fileDescriptor)
            val archive = CbzArchive(pfd, fis, fis.channel)
            try {
                archive.readCentralDirectory()
            } catch (e: Throwable) {
                archive.close()
                throw e
            }
            return archive
        }
    }

    private fun readInto(position: Long, dst: ByteBuffer) {
        var pos = position
        while (dst.hasRemaining()) {
            val n = channel.read(dst, pos)
            if (n < 0) throw IOException("ファイルが途中で終わっています")
            pos += n
        }
        dst.flip()
    }

    private fun read(position: Long, length: Int): ByteBuffer {
        val buf = ByteBuffer.allocate(length).order(ByteOrder.LITTLE_ENDIAN)
        readInto(position, buf)
        return buf
    }

    private fun u16(b: ByteBuffer, i: Int): Int = b.getShort(i).toInt() and 0xffff
    private fun u32(b: ByteBuffer, i: Int): Long = b.getInt(i).toLong() and 0xffffffffL

    private fun readCentralDirectory() {
        val fileSize = channel.size()
        if (fileSize < 22) throw IOException("ZIP形式ではありません")
        val tailLen = minOf(fileSize, 22L + 65535L).toInt()
        val tail = read(fileSize - tailLen, tailLen)

        var eocd = -1
        for (i in tailLen - 22 downTo 0) {
            if (tail.getInt(i) == 0x06054b50) { eocd = i; break }
        }
        if (eocd < 0) throw IOException("ZIP形式ではありません")

        var cdSize = u32(tail, eocd + 12)
        var cdOffset = u32(tail, eocd + 16)

        // 4GBを超えるZIP（ZIP64）
        val locator = eocd - 20
        if (locator >= 0 && tail.getInt(locator) == 0x07064b50) {
            val z64 = read(tail.getLong(locator + 8), 56)
            if (z64.getInt(0) == 0x06064b50) {
                cdSize = z64.getLong(40)
                cdOffset = z64.getLong(48)
            }
        }
        if (cdSize > Int.MAX_VALUE) throw IOException("目次が大きすぎます")

        val cd = read(cdOffset, cdSize.toInt())
        val list = ArrayList<Entry>()
        var p = 0
        while (p + 46 <= cd.limit() && cd.getInt(p) == 0x02014b50) {
            val flags = u16(cd, p + 8)
            val method = u16(cd, p + 10)
            var comp = u32(cd, p + 20)
            var size = u32(cd, p + 24)
            val nameLen = u16(cd, p + 28)
            val extraLen = u16(cd, p + 30)
            val commentLen = u16(cd, p + 32)
            var offset = u32(cd, p + 42)

            val nameBytes = ByteArray(nameLen)
            cd.position(p + 46)
            cd.get(nameBytes)
            val name = String(nameBytes, if (flags and 0x800 != 0) Charsets.UTF_8 else legacyCharset)

            var e = p + 46 + nameLen
            val eEnd = e + extraLen
            while (e + 4 <= eEnd) {
                val id = u16(cd, e)
                val len = u16(cd, e + 2)
                if (id == 0x0001) {
                    var q = e + 4
                    if (size == 0xffffffffL) { size = cd.getLong(q); q += 8 }
                    if (comp == 0xffffffffL) { comp = cd.getLong(q); q += 8 }
                    if (offset == 0xffffffffL) { offset = cd.getLong(q) }
                }
                e += 4 + len
            }

            val base = name.substringAfterLast('/')
            val ext = base.substringAfterLast('.', "").lowercase()
            if (!name.endsWith("/") && ext in IMAGE_EXT && !base.startsWith(".") && !name.startsWith("__MACOSX")) {
                list.add(Entry(name, method, comp, size, offset))
            }
            p += 46 + nameLen + extraLen + commentLen
        }
        list.sortWith { a, b -> NaturalOrder.compare(a.name, b.name) }
        pages = list
    }

    fun readBytes(entry: Entry): ByteArray {
        val lh = read(entry.localHeaderOffset, 30)
        if (lh.getInt(0) != 0x04034b50) throw IOException("壊れたページ: ${entry.name}")
        val dataStart = entry.localHeaderOffset + 30 + u16(lh, 26) + u16(lh, 28)
        if (entry.compressedSize > Int.MAX_VALUE - 1 || entry.size > Int.MAX_VALUE) {
            throw IOException("画像が大きすぎます")
        }
        val compLen = entry.compressedSize.toInt()
        // 無圧縮ならそのまま、Deflateなら展開。展開時用に1バイト余分に確保しておく
        val raw = ByteArray(compLen + 1)
        readInto(dataStart, ByteBuffer.wrap(raw, 0, compLen))
        return when (entry.method) {
            0 -> raw.copyOf(compLen)
            8 -> {
                val inflater = Inflater(true)
                try {
                    inflater.setInput(raw, 0, compLen + 1)
                    val out = ByteArray(entry.size.toInt())
                    var off = 0
                    while (off < out.size) {
                        val k = inflater.inflate(out, off, out.size - off)
                        if (k == 0 && (inflater.finished() || inflater.needsInput())) break
                        off += k
                    }
                    out
                } finally {
                    inflater.end()
                }
            }
            else -> throw IOException("未対応の圧縮形式です（${entry.method}）")
        }
    }

    override fun close() {
        runCatching { channel.close() }
        runCatching { stream.close() }
        runCatching { pfd.close() }
    }
}
