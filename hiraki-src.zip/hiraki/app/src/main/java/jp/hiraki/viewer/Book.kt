package jp.hiraki.viewer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.Closeable
import java.io.IOException

/** 本の中身（ページ画像）を取り出す共通の窓口。cbz/zipとPDFで中身の取り出し方だけが違う */
interface BookSource : Closeable {
    val pageCount: Int

    /** reqW×reqHに収まる大きさ以上でページを画像にする。hardware=trueならGPU向けの画像にする */
    fun decode(index: Int, reqW: Int, reqH: Int, hardware: Boolean): Bitmap?
}

enum class BookType { ARCHIVE, PDF }

fun bookTypeOf(name: String): BookType? {
    val lower = name.lowercase()
    return when {
        lower.endsWith(".cbz") || lower.endsWith(".zip") -> BookType.ARCHIVE
        lower.endsWith(".pdf") -> BookType.PDF
        else -> null
    }
}

fun openBook(context: Context, item: Item): BookSource = when (bookTypeOf(item.name)) {
    BookType.PDF -> PdfSource.open(context, item)
    else -> CbzSource(CbzArchive.open(context, item.uri))
}

class CbzSource(private val archive: CbzArchive) : BookSource {
    override val pageCount: Int get() = archive.pages.size

    override fun decode(index: Int, reqW: Int, reqH: Int, hardware: Boolean): Bitmap? {
        val bytes = archive.readBytes(archive.pages[index])
        if (hardware) {
            decodeSampled(bytes, reqW, reqH, Bitmap.Config.HARDWARE)?.let { return it }
        }
        return decodeSampled(bytes, reqW, reqH)?.also { if (hardware) it.prepareToDraw() }
    }

    override fun close() = archive.close()
}

/** PDFはAndroid標準のPdfRendererでページを画像にする（同時に1ページずつしか開けないので順番待ちにする） */
class PdfSource private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
) : BookSource {

    companion object {
        private const val MAX_SIDE = 4096

        fun open(context: Context, item: Item): PdfSource {
            val pfd = context.contentResolver.openFileDescriptor(item.uri, "r")
                ?: throw IOException("ファイルを開けません")
            val renderer = try {
                PdfRenderer(pfd)
            } catch (e: SecurityException) {
                pfd.close()
                throw IOException("パスワード付きのPDFは開けません")
            } catch (e: Exception) {
                pfd.close()
                throw IOException("PDFを読めませんでした")
            }
            return PdfSource(pfd, renderer)
        }
    }

    override val pageCount: Int = renderer.pageCount

    private val lock = Any()

    override fun decode(index: Int, reqW: Int, reqH: Int, hardware: Boolean): Bitmap? = synchronized(lock) {
        val page = renderer.openPage(index)
        try {
            val scale = minOf(reqW.toFloat() / page.width, reqH.toFloat() / page.height)
            var w = (page.width * scale).toInt().coerceAtLeast(1)
            var h = (page.height * scale).toInt().coerceAtLeast(1)
            val longest = maxOf(w, h)
            if (longest > MAX_SIDE) {
                w = w * MAX_SIDE / longest
                h = h * MAX_SIDE / longest
            }
            val bmp = Bitmap.createBitmap(w.coerceAtLeast(1), h.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            if (hardware) {
                val hw = bmp.copy(Bitmap.Config.HARDWARE, false)
                if (hw != null) {
                    bmp.recycle()
                    return@synchronized hw
                }
                bmp.prepareToDraw()
            }
            bmp
        } finally {
            page.close()
        }
    }

    override fun close() {
        synchronized(lock) {
            runCatching { renderer.close() }
            runCatching { pfd.close() }
        }
    }
}
