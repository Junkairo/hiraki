package jp.hiraki.viewer

import android.app.Activity
import android.content.res.Configuration
import android.graphics.Bitmap
import android.util.LruCache
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

private val ViewerBg = Color(0xFF050608)
private const val FLIP_MS = 420

/** デコード済みページの置き場。GPUに載せた状態で持っておき、めくった瞬間に描けるようにする */
class PageCache(private val archive: CbzArchive) {
    private val cache = object : LruCache<Int, Bitmap>(160 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap) = value.byteCount / 1024
    }

    fun peek(index: Int): Bitmap? = cache.get(index)

    suspend fun load(index: Int, reqW: Int, reqH: Int): Bitmap? = withContext(Dispatchers.IO) {
        cache.get(index) ?: runCatching {
            val bytes = archive.readBytes(archive.pages[index])
            decodeSampled(bytes, reqW, reqH, Bitmap.Config.HARDWARE)
                ?: decodeSampled(bytes, reqW, reqH)?.also { it.prepareToDraw() }
        }.getOrNull()?.also { cache.put(index, it) }
    }
}

@Composable
fun ViewerScreen(item: Item, prefs: BookPrefs, onClose: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    var archive by remember { mutableStateOf<CbzArchive?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(item.uri) {
        try {
            archive = withContext(Dispatchers.IO) { CbzArchive.open(context, item.uri) }
        } catch (e: Exception) {
            error = "開けませんでした（${e.message}）"
        }
    }
    DisposableEffect(item.uri) {
        onDispose { archive?.close() }
    }

    // 全画面表示・画面を消さない
    DisposableEffect(Unit) {
        val window = (view.context as Activity).window
        val controller = WindowCompat.getInsetsController(window, view)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        view.keepScreenOn = true
        onDispose {
            controller.show(WindowInsetsCompat.Type.systemBars())
            view.keepScreenOn = false
        }
    }

    Box(Modifier.fillMaxSize().background(ViewerBg)) {
        val a = archive
        when {
            error != null -> Text(error ?: "", color = SubText, modifier = Modifier.align(Alignment.Center).padding(24.dp))
            a == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
            a.pages.isEmpty() -> Text("画像が見つかりませんでした", color = SubText, modifier = Modifier.align(Alignment.Center))
            else -> BookView(item, a, prefs, onClose)
        }
    }
}

/** 見開きを左右に振り分ける。右綴じなら若い番号が右 */
private fun sidesOf(spread: IntArray, rtl: Boolean): Pair<Int?, Int?> {
    val first = spread[0]
    val second = spread.getOrNull(1)
    return if (rtl) second to first else first to second
}

@Composable
private fun BookView(item: Item, archive: CbzArchive, prefs: BookPrefs, onClose: () -> Unit) {
    val key = item.bookKey
    val count = archive.pages.size
    val cache = remember(archive) { PageCache(archive) }
    val scope = rememberCoroutineScope()

    var shifted by remember { mutableStateOf(prefs.shifted(key)) }
    var rtl by remember { mutableStateOf(prefs.rtl(key)) }
    var mode by remember { mutableStateOf(prefs.mode(key)) }
    var flipEffect by remember { mutableStateOf(prefs.flipEffect()) }
    var page by remember { mutableStateOf(prefs.page(key).coerceIn(0, count - 1)) }
    var showBar by remember { mutableStateOf(false) }

    // めくり中の状態：target=めくった先の見開き番号、progress=0→1
    var target by remember { mutableStateOf<Int?>(null) }
    val progress = remember { Animatable(0f) }

    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val spreadOn = when (mode) {
        1 -> false
        2 -> true
        else -> landscape
    }
    val spreads = remember(count, shifted, spreadOn) { buildSpreads(count, shifted, spreadOn) }
    val index = spreadIndexOf(spreads, page)

    LaunchedEffect(page, shifted, rtl, mode) {
        prefs.save(key, page, count, shifted, rtl, mode)
    }
    LaunchedEffect(flipEffect) { prefs.setFlipEffect(flipEffect) }

    // --- めくり操作 ---
    // 画面タッチの処理は最初に1回だけ作られるので、最新の値は必ずStateから読む
    val indexState = rememberUpdatedState(index)
    val spreadsState = rememberUpdatedState(spreads)
    val rtlState = rememberUpdatedState(rtl)
    val effectState = rememberUpdatedState(flipEffect)

    val handlers = remember(scope, progress) {
        object {
            fun commit(n: Int) {
                val list = spreadsState.value
                if (n in list.indices) page = list[n][0]
                target = null
            }

            fun turn(delta: Int) {
                scope.launch {
                    target?.let { commit(it) }
                    progress.snapTo(0f)
                    val n = indexState.value + delta
                    if (n !in spreadsState.value.indices) return@launch
                    if (!effectState.value) {
                        commit(n)
                        return@launch
                    }
                    target = n
                    progress.animateTo(1f, tween(FLIP_MS, easing = FastOutSlowInEasing))
                    commit(n)
                    progress.snapTo(0f)
                }
            }

            fun dragTo(dx: Float, width: Float) {
                // 右綴じ：左→右へ動かすと次のページ
                val forward = if (rtlState.value) dx > 0 else dx < 0
                val n = indexState.value + if (forward) 1 else -1
                scope.launch {
                    if (n !in spreadsState.value.indices) {
                        target = null
                        progress.snapTo(0f)
                        return@launch
                    }
                    target = n
                    progress.snapTo((abs(dx) / width).coerceIn(0f, 1f))
                }
            }

            fun dragEnd() {
                val t = target ?: return
                scope.launch {
                    if (progress.value > 0.22f) {
                        progress.animateTo(1f, tween((FLIP_MS * (1f - progress.value)).toInt().coerceAtLeast(80)))
                        commit(t)
                    } else {
                        progress.animateTo(0f, tween(160))
                        target = null
                    }
                    progress.snapTo(0f)
                }
            }
        }
    }

    val onTurn: (Int) -> Unit = { handlers.turn(it) }
    val onDragTo: (Float, Float) -> Unit = { dx, w -> handlers.dragTo(dx, w) }
    val onDragEnd: () -> Unit = { handlers.dragEnd() }
    val isRtl by rtlState
    val effectOn by effectState

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val screenW = with(density) { maxWidth.roundToPx() }
        val screenH = with(density) { maxHeight.roundToPx() }
        val pageW = if (spreadOn) screenW / 2 else screenW

        // 前後の見開きを先読み（次を2つ、前を1つ）
        LaunchedEffect(index, spreads, pageW, screenH) {
            for (d in listOf(1, 2, -1)) {
                spreads.getOrNull(index + d)?.forEach { cache.load(it, pageW, screenH) }
            }
        }

        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        val startX = down.position.x
                        val slop = viewConfiguration.touchSlop
                        var isDrag = false
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            val dx = change.position.x - startX
                            if (!change.pressed) {
                                if (isDrag) {
                                    if (effectOn) {
                                        onDragEnd()
                                    } else if (abs(dx) > 60.dp.toPx()) {
                                        val forward = if (isRtl) dx > 0 else dx < 0
                                        onTurn(if (forward) 1 else -1)
                                    }
                                } else {
                                    val w = size.width.toFloat()
                                    val x = change.position.x
                                    val longPress = change.uptimeMillis - down.uptimeMillis > 450
                                    when {
                                        longPress -> showBar = true
                                        x < w / 3f -> onTurn(if (isRtl) 1 else -1)
                                        x > w * 2f / 3f -> onTurn(if (isRtl) -1 else 1)
                                        else -> showBar = !showBar
                                    }
                                }
                                break
                            }
                            if (!isDrag && abs(dx) > slop) {
                                isDrag = true
                            }
                            if (isDrag) {
                                change.consume()
                                if (effectOn) onDragTo(dx, size.width.toFloat())
                            }
                        }
                    }
                },
        ) {
            val current = spreads[index]
            val t = target
            if (t == null) {
                StaticSpread(cache, current, spreadOn, rtl, pageW, screenH)
            } else {
                FlippingSpread(
                    cache = cache,
                    from = current,
                    to = spreads[t],
                    forward = t > index,
                    progress = progress.value,
                    spreadOn = spreadOn,
                    rtl = rtl,
                    reqW = pageW,
                    reqH = screenH,
                )
            }
        }

        if (showBar) {
            ViewerBars(
                title = item.title,
                current = spreads[index],
                count = count,
                spreads = spreads,
                index = index,
                rtl = rtl,
                mode = mode,
                shifted = shifted,
                spreadOn = spreadOn,
                flipEffect = flipEffect,
                onClose = onClose,
                onMode = { mode = it },
                onRtl = { rtl = it },
                onShift = { shifted = !shifted },
                onFlipEffect = { flipEffect = it },
                onSeek = { page = spreads[it][0] },
            )
        }
    }
}

/** 止まっているときの表示 */
@Composable
private fun StaticSpread(cache: PageCache, spread: IntArray, spreadOn: Boolean, rtl: Boolean, reqW: Int, reqH: Int) {
    if (!spreadOn) {
        PageImage(cache, spread[0], reqW, reqH, Alignment.Center, Modifier.fillMaxSize())
        return
    }
    val (left, right) = sidesOf(spread, rtl)
    Row(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxHeight()) {
            if (left != null) PageImage(cache, left, reqW, reqH, Alignment.CenterEnd, Modifier.fillMaxSize())
        }
        Box(Modifier.weight(1f).fillMaxHeight()) {
            if (right != null) PageImage(cache, right, reqW, reqH, Alignment.CenterStart, Modifier.fillMaxSize())
        }
    }
}

/**
 * 紙をめくる表示。
 * 見開き：めくる側の紙が綴じ目を軸に立ち上がり（前半）、反対側に倒れる（後半）。
 * 単ページ：いまの紙が綴じ目を軸にめくれて、下から次のページが現れる。
 */
@Composable
private fun FlippingSpread(
    cache: PageCache,
    from: IntArray,
    to: IntArray,
    forward: Boolean,
    progress: Float,
    spreadOn: Boolean,
    rtl: Boolean,
    reqW: Int,
    reqH: Int,
) {
    val p = progress.coerceIn(0f, 1f)

    if (!spreadOn) {
        // 綴じ目：右綴じなら右端、左綴じなら左端
        val pivotRight = rtl
        val (bottom, top, angle) = if (forward) {
            Triple(to[0], from[0], p * 90f)
        } else {
            Triple(from[0], to[0], (1f - p) * 90f)
        }
        Box(Modifier.fillMaxSize()) {
            Leaf(cache, bottom, reqW, reqH, Alignment.Center, shade = (angle / 90f) * 0.45f)
            Leaf(
                cache, top, reqW, reqH, Alignment.Center,
                shade = (angle / 90f) * 0.3f,
                modifier = Modifier.zIndex(1f).flip(angle, pivotRight),
            )
        }
        return
    }

    val (oL, oR) = sidesOf(from, rtl)
    val (nL, nR) = sidesOf(to, rtl)
    // 右綴じで次へ進むときは、左側の紙が右へめくれる
    val fromLeft = forward == rtl
    val firstHalf = p < 0.5f
    val up = if (firstHalf) p * 2f * 90f else 90f          // 立ち上がる紙の角度
    val down = if (firstHalf) 90f else (1f - p) * 2f * 90f // 倒れてくる紙の角度
    val revealShade = if (firstHalf) (1f - p * 2f) * 0.45f else 0f
    val coverShade = if (firstHalf) 0f else (p - 0.5f) * 2f * 0.45f

    Row(Modifier.fillMaxSize()) {
        // 左半分
        Box(Modifier.weight(1f).fillMaxHeight().zIndex(if (fromLeft == firstHalf) 1f else 0f)) {
            if (fromLeft) {
                Leaf(cache, nL, reqW, reqH, Alignment.CenterEnd, shade = revealShade)
                if (firstHalf) {
                    Leaf(cache, oL, reqW, reqH, Alignment.CenterEnd, shade = up / 90f * 0.3f,
                        modifier = Modifier.zIndex(1f).flip(up, pivotRight = true))
                }
            } else {
                Leaf(cache, oL, reqW, reqH, Alignment.CenterEnd, shade = coverShade)
                if (!firstHalf) {
                    Leaf(cache, nL, reqW, reqH, Alignment.CenterEnd, shade = down / 90f * 0.3f,
                        modifier = Modifier.zIndex(1f).flip(down, pivotRight = true))
                }
            }
        }
        // 右半分
        Box(Modifier.weight(1f).fillMaxHeight().zIndex(if (fromLeft != firstHalf) 1f else 0f)) {
            if (fromLeft) {
                Leaf(cache, oR, reqW, reqH, Alignment.CenterStart, shade = coverShade)
                if (!firstHalf) {
                    Leaf(cache, nR, reqW, reqH, Alignment.CenterStart, shade = down / 90f * 0.3f,
                        modifier = Modifier.zIndex(1f).flip(down, pivotRight = false))
                }
            } else {
                Leaf(cache, nR, reqW, reqH, Alignment.CenterStart, shade = revealShade)
                if (firstHalf) {
                    Leaf(cache, oR, reqW, reqH, Alignment.CenterStart, shade = up / 90f * 0.3f,
                        modifier = Modifier.zIndex(1f).flip(up, pivotRight = false))
                }
            }
        }
    }
}

/** 綴じ目を軸に紙を回転させる（手前に起き上がる向き） */
private fun Modifier.flip(angle: Float, pivotRight: Boolean): Modifier = this.graphicsLayer {
    transformOrigin = TransformOrigin(if (pivotRight) 1f else 0f, 0.5f)
    rotationY = if (pivotRight) angle else -angle
    cameraDistance = 14f * density
}

/** 1枚の紙（背景つき）。shadeは影の濃さ */
@Composable
private fun Leaf(
    cache: PageCache,
    index: Int?,
    reqW: Int,
    reqH: Int,
    alignment: Alignment,
    shade: Float,
    modifier: Modifier = Modifier,
) {
    Box(modifier.fillMaxSize().background(ViewerBg)) {
        if (index != null) PageImage(cache, index, reqW, reqH, alignment, Modifier.fillMaxSize())
        if (shade > 0.01f) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = shade.coerceIn(0f, 0.8f))))
        }
    }
}

@Composable
private fun PageImage(cache: PageCache, index: Int, reqW: Int, reqH: Int, alignment: Alignment, modifier: Modifier) {
    // ページ番号が変わったら必ず作り直す（前のページの画像を引きずらない）
    val state = remember(index, reqW, reqH) { mutableStateOf(cache.peek(index)) }
    LaunchedEffect(index, reqW, reqH) {
        if (state.value == null) state.value = cache.load(index, reqW, reqH)
    }
    val bitmap = state.value
    Box(modifier) {
        val bmp = bitmap
        if (bmp != null) {
            val image = remember(bmp) { bmp.asImageBitmap() }
            Image(
                image,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                alignment = alignment,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = SubText)
        }
    }
}

@Composable
private fun ViewerBars(
    title: String,
    current: IntArray,
    count: Int,
    spreads: List<IntArray>,
    index: Int,
    rtl: Boolean,
    mode: Int,
    shifted: Boolean,
    spreadOn: Boolean,
    flipEffect: Boolean,
    onClose: () -> Unit,
    onMode: (Int) -> Unit,
    onRtl: (Boolean) -> Unit,
    onShift: () -> Unit,
    onFlipEffect: (Boolean) -> Unit,
    onSeek: (Int) -> Unit,
) {
    val barColor = Color(0xEB1B2029)
    Box(Modifier.fillMaxSize()) {
        // 上のバー
        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .pointerInput(Unit) { detectTapGestures { } }
                .background(barColor)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "本棚へ戻る", tint = Color.White)
            }
            Text(
                title,
                color = SubText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Segmented(listOf("自動", "単", "見開"), mode, onMode)
            Segmented(listOf("右綴じ", "左綴じ"), if (rtl) 0 else 1) { onRtl(it == 0) }
            Segmented(listOf("めくり", "なし"), if (flipEffect) 0 else 1) { onFlipEffect(it == 0) }
        }

        // 下のバー
        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .pointerInput(Unit) { detectTapGestures { } }
                .background(barColor)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            val shiftColor = when {
                !spreadOn -> Color(0xFF3A4250)
                shifted -> Accent
                else -> Color(0xFF2E3542)
            }
            Text(
                if (shifted) "⇆ ずらし中" else "⇆ 1ページずらす",
                color = if (spreadOn) Color.White else SubText,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(shiftColor)
                    .clickable(enabled = spreadOn, onClick = onShift)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            )
            Box(Modifier.weight(1f)) {
                if (spreads.size > 1) {
                    // 右綴じのときはスライダーも右から左へ
                    CompositionLocalProvider(
                        LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
                    ) {
                        Slider(
                            value = index.toFloat(),
                            onValueChange = { onSeek(it.roundToInt().coerceIn(0, spreads.lastIndex)) },
                            valueRange = 0f..spreads.lastIndex.toFloat(),
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Accent),
                        )
                    }
                }
            }
            val label = if (current.size == 2) "${current[0] + 1}–${current[1] + 1}" else "${current[0] + 1}"
            Text("$label / $count", color = SubText, fontSize = 13.sp)
        }
    }
}

@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF3A4250), RoundedCornerShape(8.dp)),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Text(
                label,
                color = if (on) Color(0xFF111111) else SubText,
                fontSize = 13.sp,
                modifier = Modifier
                    .background(if (on) Color(0xFFE9ECF1) else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}
